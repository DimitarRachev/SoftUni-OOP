import animals.*;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String type = scanner.nextLine();
        while (!"Beast!".equals(type)) {
            String[] input = scanner.nextLine().split("\\s+");
            Animal animal = null;
            try {
                switch (type) {
                    case "Dog":
                        animal = new Dog(input[0], Integer.parseInt(input[1]), input[2]);
                        break;
                    case "Frog":
                        animal = new Frog(input[0], Integer.parseInt(input[1]), input[2]);
                        break;
                    case "Cat":
                        animal = new Cat(input[0], Integer.parseInt(input[1]), input[2]);
                    case "Kitten":
                        animal = new Tomcat(input[0], Integer.parseInt(input[1]));
                        break;
                    case "Tomcat":
                        animal = new Kitten(input[0], Integer.parseInt(input[1]));
                        break;
                }
                System.out.println(animal);
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
            type = scanner.nextLine();
        }
    }
}
