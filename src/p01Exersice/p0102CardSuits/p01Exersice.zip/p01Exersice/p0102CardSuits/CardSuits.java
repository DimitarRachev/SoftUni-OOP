package p01Exersice.p0102CardSuits;

public enum CardSuits {
    CLUBS, DIAMONDS, HEARTS, SPADES;
}
